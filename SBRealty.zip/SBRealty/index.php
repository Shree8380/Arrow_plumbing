<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>SB Realty</title>

    <!-- Bootstrap -->
    <script defer src="scripts/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="styles/bootstrap.min.css" />
    <!-- Swiper Js -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <link rel="stylesheet" href="styles/main.css" />
  </head>
  <body>
    <header>
      <?php include 'includes/Navbar.php';?>
    </header>

    <main>
      <!-- Hero Section -->
      <section
        class="position-relative"
        style="
          min-height: 300px;
          height: 600px;
          max-height: 60vh;
          background-image: url(images/home-hero.jpg);
          background-position: center;
          background-size: cover;
        "
      >
        <!-- <img src="images/hero-sm.jpg" class="img-fluid w-100 d-block d-md-none" /> -->
        <div class="container position-absolute start-50 translate-middle-x d-flex" style="bottom: 10%">
          <div class="bg-dark rounded-1 p-3 d-flex flex-wrap flex-lg-nowrap gap-2 align-items-end mx-auto">
            <div class="flex-fill" style="min-width: 300px">
              <label for="search-input" class="mb-1 text-white small">SEARCH FOR HOMES</label>
              <input
                type="text"
                class="form-control form-control-sm"
                id="search-input"
                placeholder="City, neighborhoood, zip, or address"
              />
            </div>
            <div class="flex-fill">
              <label for="search-input" class="mb-1 text-white small">PRICE</label>
              <input
                type="text"
                class="form-control form-control-sm"
                id="search-input"
                placeholder="Min Price - Max Price"
              />
            </div>
            <div class="flex-fill">
              <label for="search-input" class="mb-1 text-white small">BEDS</label>
              <select
                type="text"
                class="form-select form-select-sm"
                id="search-input"
                placeholder="Min Price - Max Price"
              >
                <option value="">Any</option>
                <option value="">Any</option>
                <option value="">Any</option>
                <option value="">Any</option>
              </select>
            </div>
            <div class="flex-fill">
              <label for="search-input" class="mb-1 text-white small">BATHS</label>
              <select
                type="text"
                class="form-select form-select-sm"
                id="search-input"
                placeholder="Min Price - Max Price"
              >
                <option value="">Any</option>
                <option value="">Any</option>
                <option value="">Any</option>
                <option value="">Any</option>
              </select>
            </div>
            <button type="submit" class="btn btn-primary btn-sm px-3">
              <img src="images/search-icon.png" alt="search icon" height="16" />
              Search
            </button>
          </div>
        </div>
      </section>

      <!-- Welcome Section -->
      <section>
        <div class="container text-center py-4">
          <h4 class="fw-light">WELCOME TO SB REALTY & PROPERTY MANAGEMENT</h4>
          <p>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Hic ut, architecto quasi vitae voluptatem,
            eligendi maiores obcaecati consequuntur iste nobis odit dolorum. Amet repellat nisi cupiditate, quisquam
            porro hic autem doloremque quod esse animi omnis reprehenderit ab consectetur provident deleniti suscipit?
            Consequuntur similique numquam veniam maiores autem. Porro facere nulla impedit fugit ea, placeat unde dicta
            possimus minus? A esse dignissimos quae dolor delectus eum fugiat cupiditate possimus fugit voluptatum!
          </p>
        </div>
      </section>

      <!-- Just Listed -->
      <section class="bg-light pt-4 position-relative pb-5">
        <div class="container">
          <!-- Slider main container -->
          <h4 class="text-center fw-normal">JUST LISTED!</h4>
          <div class="swiper mt-3">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">
              <!-- Slides -->
              <div class="swiper-slide">
                <img src="images/home1.jpg" class="w-100" />
                <div class="bg-secondary text-white p-3 d-flex justify-content-between gap-2">
                  <div>
                    <small>Mena</small>
                    <h5 class="m-0 fw-normal">$172,000</h5>
                  </div>
                  <div>
                    <small>Beds</small>
                    <p class="m-0">3</p>
                  </div>
                  <div>
                    <small>Baths</small>
                    <p class="m-0">1.5</p>
                  </div>
                  <div>
                    <small>Sq.Ft.</small>
                    <p class="m-0">1378</p>
                  </div>
                  <div class="align-self-center">
                    <img src="images/Shape 14.png" height="32" />
                  </div>
                </div>
                <div class="d-flex justify-content-between gap-2 py-2 align-items-center">
                  <a href="#" class="text-decoration-none link-dark">
                    <img src="images/search-file.png" height="22" /> <span class="align-middle ps-1">View Details</span>
                  </a>
                  <a href="#" class="text-decoration-none link-dark">
                    <img src="images/house (7).png" height="22" />
                    <span class="align-middle ps-1">Similar Properties</span>
                  </a>
                </div>
              </div>
              <div class="swiper-slide">
                <img src="images/Layer 525.jpg" class="w-100" />
                <div class="bg-secondary text-white p-3 d-flex justify-content-between gap-2">
                  <div>
                    <small>Camden</small>
                    <h5 class="m-0 fw-normal">$179,000</h5>
                  </div>
                  <div>
                    <small>Beds</small>
                    <p class="m-0">3</p>
                  </div>
                  <div>
                    <small>Baths</small>
                    <p class="m-0">2</p>
                  </div>
                  <div>
                    <small>Sq.Ft.</small>
                    <p class="m-0">1456</p>
                  </div>
                  <div class="align-self-center">
                    <img src="images/Shape 14.png" height="32" />
                  </div>
                </div>
                <div class="d-flex justify-content-between gap-2 py-2 align-items-center">
                  <a href="#" class="text-decoration-none link-dark">
                    <img src="images/search-file.png" height="22" /> <span class="align-middle ps-1">View Details</span>
                  </a>
                  <a href="#" class="text-decoration-none link-dark">
                    <img src="images/house (7).png" height="22" />
                    <span class="align-middle ps-1">Similar Properties</span>
                  </a>
                </div>
              </div>
              <div class="swiper-slide">
                <img src="images/Layer 526.jpg" class="w-100" />
                <div class="bg-secondary text-white p-3 d-flex justify-content-between gap-2">
                  <div>
                    <small>Paris</small>
                    <h5 class="m-0 fw-normal">$1.050,000</h5>
                  </div>
                  <div>
                    <small>Beds</small>
                    <p class="m-0">2</p>
                  </div>
                  <div>
                    <small>Baths</small>
                    <p class="m-0">2</p>
                  </div>
                  <div>
                    <small>Sq.Ft.</small>
                    <p class="m-0">1344</p>
                  </div>
                  <div class="align-self-center">
                    <img src="images/Shape 14.png" height="32" />
                  </div>
                </div>
                <div class="d-flex justify-content-between gap-2 py-2 align-items-center">
                  <a href="#" class="text-decoration-none link-dark">
                    <img src="images/search-file.png" height="22" /> <span class="align-middle ps-1">View Details</span>
                  </a>
                  <a href="#" class="text-decoration-none link-dark">
                    <img src="images/house (7).png" height="22" />
                    <span class="align-middle ps-1">Similar Properties</span>
                  </a>
                </div>
              </div>
              <div class="swiper-slide">
                <img src="images/Layer 527.jpg" class="w-100" />
                <div class="bg-secondary text-white p-3 d-flex justify-content-between gap-2">
                  <div>
                    <small>Corning</small>
                    <h5 class="m-0 fw-normal">$24,000</h5>
                  </div>
                  <div>
                    <small>Beds</small>
                    <p class="m-0">2</p>
                  </div>
                  <div>
                    <small>Baths</small>
                    <p class="m-0">1</p>
                  </div>
                  <div>
                    <small>Sq.Ft.</small>
                    <p class="m-0">1864</p>
                  </div>
                  <div class="align-self-center">
                    <img src="images/Shape 14.png" height="32" />
                  </div>
                </div>
                <div class="d-flex justify-content-between gap-2 py-2 align-items-center">
                  <a href="#" class="text-decoration-none link-dark">
                    <img src="images/search-file.png" height="22" /> <span class="align-middle ps-1">View Details</span>
                  </a>
                  <a href="#" class="text-decoration-none link-dark">
                    <img src="images/house (7).png" height="22" />
                    <span class="align-middle ps-1">Similar Properties</span>
                  </a>
                </div>
              </div>
            </div>
            <!-- If we need navigation buttons -->
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
          </div>
        </div>
        <a href="#" class="btn btn-secondary px-4 rounded-0 position-absolute start-50 top-100 translate-middle"
          >View All Recent Listings</a
        >
      </section>
      <!-- Cards Section -->
      <section class="py-5">
        <div class="container">
          <div class="row g-4 align-items-center justify-content-center">
            <div class="col-12 col-md-6 col-lg-4">
              <div class="p-3 bg-info text-white text-center position-relative">
                <img src="images/sold.png" alt="sold" style="max-height: 200px" />
                <h5 class="mt-3 fw-light">BUYING OR SELLLING?</h5>
                <p class="text-start pb-4">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam mollitia assumenda cupiditate harum.
                  Ipsum modi vel repellat tempore, harum expedita corrupti iusto eaque aut ex? Pariatur illo doloremque
                  itaque laborum optio doloribus?
                </p>
                <a
                  href="#"
                  class="btn btn-sm text-nowrap btn-dark px-5 rounded-0 position-absolute start-50 top-100 translate-middle w-auto"
                  >Let's Get Started</a
                >
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
              <div class="p-3 bg-white text-center position-relative">
                <img src="images/rent (1).png" alt="rent" style="max-height: 200px" />
                <h5 class="mt-3 fw-light">LOOKING FOR A RENTAL?</h5>
                <p class="text-start pb-4">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam mollitia assumenda cupiditate harum.
                  Ipsum modi vel repellat tempore, harum expedita corrupti iusto eaque aut ex? Pariatur illo doloremque
                  itaque laborum optio doloribus?
                </p>
                <a
                  href="#"
                  class="btn btn-sm text-nowrap btn-dark px-5 rounded-0 position-absolute start-50 top-100 translate-middle w-auto"
                  >Find a Rental</a
                >
              </div>
            </div>
            <div class="col-12 col-md-6 col-lg-4">
              <div class="p-3 bg-info text-white text-center position-relative">
                <img src="images/property.png" alt="property" style="max-height: 200px" />
                <h5 class="mt-3 fw-light">PROPERTY MANAGEMENT SERVICES</h5>
                <p class="text-start pb-4">
                  Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam mollitia assumenda cupiditate harum.
                  Ipsum modi vel repellat tempore, harum expedita corrupti iusto eaque aut ex? Pariatur illo doloremque
                  itaque laborum optio doloribus?
                </p>
                <a
                  href="#"
                  class="btn btn-sm text-nowrap btn-dark px-5 rounded-0 position-absolute start-50 top-100 translate-middle w-auto"
                  >View Our Services</a
                >
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- TEAM Section -->
      <section class="py-5 team-section position-relative">
        <div class="arrow-down position-absolute top-0 start-50 translate-middle-x border-white"></div>
        <div class="arrow-up position-absolute bottom-0 start-50 translate-middle-x border-white"></div>
        <div class="container text-center">
          <div class="row g-4 align-items-center justify-content-center">
            <div class="col-10 col-lg order-lg-1">
              <h4 class="fw-bold text-primary">MEET THE TEAM</h4>
              <p>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusamus optio nemo provident iure numquam
                dolorum quasi dolor doloremque quos error maiores, atque illo, quia voluptatum, molestiae aperiam
                excepturi reiciendis itaque.
              </p>

              <div class="d-flex gap-2 justify-content-center">
                <a href="#" class="btn btn-dark rounded-0">Contact Us</a>
                <a href="#" class="btn btn-primary rounded-0">Join the Team</a>
              </div>
            </div>
            <div class="col-auto text-primary">
              <img src="images/person1.png" alt="Jacb Sisson" style="max-height: 300px" />
              <h2 class="fw-light mt-2 mb-0">Erika Sisson</h2>
              <h6 class="fw-normal m-0">Executive Broker</h6>
            </div>

            <div class="col-auto text-primary order-lg-2">
              <img src="images/person2.png" alt="Jacb Sisson" style="max-height: 300px" />
              <h2 class="fw-light mt-2 mb-0">Jacb Sisson</h2>
              <h6 class="fw-normal m-0">Principall Broker</h6>
            </div>
          </div>
        </div>
      </section>

      <!-- Why Choose Us Section -->
      <section class="container text-center py-5">
        <div class="d-flex align-items-center gap-4">
          <div class="border-top border-2 border-info flex-fill"></div>
          <h3 class="fw-bold m-0">WHY CHOOSE SB REALTY?</h3>
          <div class="border-top border-2 border-info flex-fill"></div>
        </div>
        <p>
          Our full-service real estate and property management company, along with our sister companies, provide
          everything you need in one place. From purchasing your investment property to rehabbing it, renting it out and
          even reselling it when the time is right, we streamline the entire process for you.
        </p>
        <div class="d-flex flex-wrap justify-content-around gap-4">
          <div>
            <img src="images/Group 103.png" alt="" height="200" />
            <h4 class="fw-normal mt-3 mb-0">
              PERSONALIZED <br />
              SERVICE
            </h4>
          </div>
          <div>
            <img src="images/Group 102.png" alt="" height="200" />
            <h4 class="fw-normal mt-3 mb-0">
              LOCAL <br />
              EXPERTISE
            </h4>
          </div>
          <div>
            <img src="images/Group 105.png" alt="" height="200" />
            <h4 class="fw-normal mt-3 mb-0">
              ONE STOP <br />
              SHOP
            </h4>
          </div>
        </div>
      </section>

      <!-- Testimonial Section -->
      <section class="bg-light py-4 text-center testimonial-section position-relative" data-bs-theme="dark">
        <div class="arrow-up position-absolute bottom-100 start-50 translate-middle-x border-light"></div>

        <div class="container">
          <img src="images/5 Point Star 1 copy 2.png" width="170" />
          <h2 class="fw-light mt-3">Satisfied Clients</h2>
          <div
            id="carouselExampleIndicators"
            class="carousel slide mt-2"
            data-bs-ride="carousel"
            data-bs-interval="6000"
          >
            <div class="carousel-inner">
              <div class="carousel-item active">
                <div class="p-3 mx-5">
                  <figure class="mb-">
                    <blockquote class="blockquote">
                      <p class="fs-6">
                        "We are Real Estate Investors and have several properties in different states. SB Realty
                        exceeded our expectations in a renovation project this past summer and by far is the best
                        Property Management group we work with. Erika has responded to our questions or request in a
                        timely manner and always gives affordable options when looking for maintenance
                        contractors/fixes. We will be using them in future projects and highly recommend their
                        services."
                      </p>
                    </blockquote>
                    <figcaption class="blockquote-footer fs-6">Tess A.</figcaption>
                  </figure>
                </div>
              </div>
              <div class="carousel-item">
                <div class="p-3 mx-5">
                  <figure class="mb-">
                    <blockquote class="blockquote">
                      <p class="fs-6">
                        "Erika was amazing in helping us find our new home,very patient and great with advice!"
                      </p>
                    </blockquote>
                    <figcaption class="blockquote-footer fs-6">Tristan T.</figcaption>
                  </figure>
                </div>
              </div>
              <div class="carousel-item">
                <div class="p-3 mx-5">
                  <figure class="mb-">
                    <blockquote class="blockquote">
                      <p class="fs-6">
                        "Erika was amazing in helping us find our new home,very patient and great with advice!"
                      </p>
                    </blockquote>
                    <figcaption class="blockquote-footer fs-6">Tristan T.</figcaption>
                  </figure>
                </div>
              </div>
              <div class="carousel-item">
                <div class="p-3 mx-5">
                  <figure class="mb-">
                    <blockquote class="blockquote">
                      <p class="fs-6">"SB Realty provided tremendous help throughout the Home-Buying process."</p>
                    </blockquote>
                    <figcaption class="blockquote-footer fs-6">Michael C.</figcaption>
                  </figure>
                </div>
              </div>
            </div>
            <button
              class="carousel-control-prev"
              type="button"
              data-bs-target="#carouselExampleIndicators"
              data-bs-slide="prev"
              style="width: auto"
            >
              <span class="carousel-control-prev-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Previous</span>
            </button>
            <button
              class="carousel-control-next"
              type="button"
              data-bs-target="#carouselExampleIndicators"
              data-bs-slide="next"
              style="width: auto"
            >
              <span class="carousel-control-next-icon" aria-hidden="true"></span>
              <span class="visually-hidden">Next</span>
            </button>

            <div class="carousel-indicators position-relative mt-2">
              <button
                type="button"
                data-bs-target="#carouselExampleIndicators"
                data-bs-slide-to="0"
                class="active"
                aria-current="true"
                aria-label="Slide 1"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleIndicators"
                data-bs-slide-to="1"
                aria-label="Slide 2"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleIndicators"
                data-bs-slide-to="2"
                aria-label="Slide 3"
              ></button>
              <button
                type="button"
                data-bs-target="#carouselExampleIndicators"
                data-bs-slide-to="3"
                aria-label="Slide 4"
              ></button>
            </div>
          </div>
        </div>
      </section>

      <!-- Contect Section -->
      <section class="text-white py-5">
        <div class="d-flex justify-content-center">
          <h3
            class="m-0 bg-dark py-2 px-5"
            style="clip-path: polygon(10% 0%, 90% 0%, 100% 100%, 0% 100%); transform: translateY(2px)"
          >
            SEND US A MESSAGE
          </h3>
        </div>
        <div class="bg-dark py-4">
          <div class="container text-center">
            <p>
              Elevate your property management experience with the personal touch of SB Realty. Contact us today to
              explore how our services can enhance the performance and value of your Central Arkansas rentals.
            </p>
            <div class="row g-3 text-start">
              <div class="col-12 col-lg-6">
                <div class="mb-2">
                  <label for="email-input">Name:</label>
                  <input type="text" class="form-control form-control-sm rounded-0" id="name-input" />
                </div>
                <div class="mb-2">
                  <label for="phone-input">Phone:</label>
                  <input type="text" class="form-control form-control-sm rounded-0" id="phone-input" />
                </div>
                <div class="mb-2">
                  <label for="email-input">Emai:</label>
                  <input type="email" class="form-control form-control-sm rounded-0" id="email-input" />
                </div>
              </div>
              <div class="col-12 col-lg-6">
                <label for="message-input">Message:</label>
                <textarea class="form-control form-control-sm rounded-0" id="message-input" rows="7"></textarea>
              </div>
            </div>
            <input type="submit" class="btn btn-primary px-5 text-white fw-bold rounded-0 mt-4" value="Submit" />
          </div>
        </div>
      </section>
    </main>

    <footer class="bg-secondary py-4 text-white">
      <div class="container">
        <div class="d-flex flex-column flex-md-row gap-4 align-items-stretch">
          <div>
            <img src="images/sbr-logo-white.png" alt="sbr realty" height="120" />
            <p class="mt-2 mb-0">
              700 e 9th St Suite 1A Little Rock, AR 72202
              <br />
              501-382-1087
            </p>
          </div>
          <div class="border border-dark"></div>
          <div>
            <div class="d-flex flex-wrap gap-3">
              <img height="50" src="images/Broker Reciprocity.png" alt="Broker Reciprocity" />
              <img
                height="50"
                src="images/2020_MLS_FINAL_BLACK_TRANSPARENT (1) copy.png"
                alt="2020 MLS Final Black Transparent"
              />
              <img
                height="50"
                src="images/equal-housing-opportunity-logo-png-transparent copy.png"
                alt="equal housing opportunity"
              />
              <img height="50" src="images/facebook (3) copy.png" alt="facebook" />
            </div>
            <h5 class="m-0 mt-2">MLS®️ Disclaimer</h5>
            <p class="small">
              Cooperative Arkansas REALTORS® MLS, Inc. All information deemed reliable but not guaranteed. All
              properties are subject to prior sale, change or withdrawal. Neither listing broker(s) or information
              provider(s) shall be responsible for any typographical errors, misinformation, misprints and shall be held
              totally harmless. Listing(s) information is provided for consumer's personal, non-commercial use and may
              not be used for any purpose other than to identify prospective properties consumers may be interested in
              purchasing. The data relating to real estate for sale on this website comes in part from the Internet Data
              Exchange program of the Multiple Listing Service. Real estate listings held by brokerage firms other than
              SB Realty & Property Management may be marked with the Internet Data Exchange logo and detailed
              information about those properties will include the name of the listing broker(s) when required by the
              MLS. Copyright ©2024 All rights reserved. Last Updated: August 13, 2024 3:13 PM UTC
            </p>
          </div>
        </div>
      </div>
    </footer>

    <script>
      const swiper = new Swiper(".swiper", {
        loop: true,

        slidesPerView: 1,
        spaceBetween: 10,

        breakpoints: {
          // when window width is >= 768px
          768: {
            slidesPerView: 2,
            spaceBetween: 20,
          },
          // when window width is >= 992px
          992: {
            slidesPerView: 3,
            spaceBetween: 20,
          },
          // when window width is >= 1200px
          1400: {
            slidesPerView: 4,
            spaceBetween: 20,
          },
        },

        // Navigation arrows
        navigation: {
          nextEl: ".swiper-button-next",
          prevEl: ".swiper-button-prev",
        },
      });
    </script>
  </body>
</html>
