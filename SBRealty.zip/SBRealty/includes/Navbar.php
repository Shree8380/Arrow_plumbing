<!-- Navbar  -->
<header class="position-relative">
  <nav class="navbar navbar-expand-lg">
    <div class="container flex-lg-column">
      <a class="navbar-brand mx-auto mt-4" href="/">
        <img src="images/nav1.png" class="d-none d-md-inline" height="50" alt="sbr logo" />
        <img src="images/sbr-logo.png" class="mx-3" height="80" alt="sbr logo" />
        <img src="images/nav2.png" class="d-none d-md-inline" height="50" alt="sbr logo" />
      </a>
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="#">HOME</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/about.html">BUYING</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">SELLING</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">RENTALS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">PROPERTY MANAGEMENT</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/Jan-Feb-March2024MenuLCCA2.pdf">MEET OUR TEAM</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">TESTIMONIALS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">CONTACT US</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</header>
